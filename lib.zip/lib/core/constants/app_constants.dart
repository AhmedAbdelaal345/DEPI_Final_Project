abstract class AppConstants {
  static final String emailRegExp = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
  static final String brainLogo = 'assets/images/brain_logo.png';
  static final String googleLogo = 'assets/images/google_logo.png';
  static final String facebookLogo = 'assets/images/facebook_logo.png';
  static final String appleLogo = 'assets/images/apple_logo.png';
  static final String text = 'question';
  static final String options = 'option';
  static final String correctAnswer = 'answer';
  static final String questionsCollection = 'questions';
  static final String question = 'question';
  static final String quizzesCollection = 'Quizzes';
  static final String quizzessmall = 'quizzes';
  static final String teacherCollection = 'teacher';
  static final String studentCollection = 'Student';
  static final String createdAt = 'createdAt';
  static final String score = 'score';
  static final String total = 'total';
  static final String status = 'status';
  static final String submittedAt = 'submittedAt';
  static final String details = 'details';
  static final String title = 'title';
  static final String id = 'id';
  static final String uId = "uid";
  static final String quizId = "quizid";
  static final String teacherId = "teacherId";
  static final String accuracy = 'accuracy';
  static final String answer = 'answer';
  static final String subject = 'subject';
  static final String duration = "duration";
  static final String quesCount = "question_count";
  static final String name = "name";
  static final String teacherName = "teacherName";
  static final String studentAnswer = "studentAnswer";
  static final String chatRoom = 'chat_rooms';
  static final String messagesCollection = 'messages';

  // static final RegExp phoneRegExp = RegExp(r'^\d{1,14}$');
  
}
